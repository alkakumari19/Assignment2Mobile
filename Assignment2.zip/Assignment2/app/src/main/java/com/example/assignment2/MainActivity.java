package com.example.assignment2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

public class MainActivity extends AppCompatActivity {

    public static final int DefaultUpdateInterval = 30;
    public static final int FastUpdateInterval = 5;
    private static final int PERMISSION_FINE_LOCATION = 80;

    //we will be referencing all of the individual ui elements im here.
    //we are going to start with the textview

    TextView tv_lat, tv_lon, tv_altitude, tv_accuracy, tv_speed, tv_sensor, tv_updates, tv_address;

    @SuppressLint("UseSwitchCompatOrMaterialCode")
    Switch sw_locationupdates, sw_gps;

    //This variable helps to check if we are tracking a location or not
    boolean updateOn = false;

    //This is another class for the location request
    // It is a config file, which is a class that had lots of properties that will influence the way the FusedLocationProvider works
    LocationRequest locationRequest;

    LocationCallback locationCallBack;

    //making a new class
    //This is one of the most important class in the application as majority of the app functions will be using this class
    // This is Google's API for location services
    FusedLocationProviderClient fusedLocationProviderClient;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Here we will give each of the UI varaibles a value

        tv_lat = findViewById(R.id.tv_lat);
        tv_lon = findViewById(R.id.tv_lon);
        tv_altitude = findViewById(R.id.tv_altitude);
        tv_accuracy = findViewById(R.id.tv_accuracy);
        tv_speed = findViewById(R.id.tv_speed);
        tv_sensor = findViewById(R.id.tv_sensor);
        tv_updates = findViewById(R.id.tv_updates);
        tv_address = findViewById(R.id.tv_address);
        sw_locationupdates = findViewById(R.id.sw_locationsupdates);
        sw_gps = findViewById(R.id.sw_gps);


        //initiating
        // we will set all the property components of the LocationRequest
        locationRequest = new LocationRequest();
        //This checks how often does the default location checker occur
        locationRequest.setInterval(1000 * DefaultUpdateInterval);

        //This checks how often the location check occurs  when set to the most frequent update
        locationRequest.setFastestInterval(1000 * FastUpdateInterval);

        locationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);


        locationCallBack = new LocationCallback() {

            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {
                super.onLocationResult(locationResult);
                //save the location
                Location location = locationResult.getLastLocation();
                updateUIValues(location);
            }
        };


        sw_gps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Here we will be checking if the switch is turned on
                if (sw_gps.isChecked()) {
                    //This is the most accurate use
                    locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
                    tv_sensor.setText("Using GPS sensors");

                } else {
                    locationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
                    tv_sensor.setText("Using Towers + WIFI");

                }
            }

        });

        sw_locationupdates.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sw_locationupdates.isChecked()) {
                    //turn on location tracking
                    startLocationUpdates();


                } else {
                    //turn off
                    stopLocationUpdates();

                }
            }
        });

        updateGPS();
    } // we finish our onCreate method here

    private void stopLocationUpdates() {

        tv_updates.setText("Location not being tracked");
        tv_lat.setText("Location not being tracked");
        tv_lon.setText("Location not being tracked");
        tv_speed.setText("Location not being tracked");
        tv_address.setText("Location not being tracked");
        tv_accuracy.setText("Location not being tracked");
        tv_altitude.setText("Location not being tracked");
        tv_sensor.setText("Location not being tracked");

        fusedLocationProviderClient.removeLocationUpdates(locationCallBack);

    }

    private void startLocationUpdates() {

        tv_updates.setText("Location is being tracked");
        LocationCallback locationCallBack = null;
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        fusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallBack, null);
        updateGPS();
    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode){
            case PERMISSION_FINE_LOCATION:
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED){
                updateGPS();
            }
            else{
                Toast.makeText(this , "This app requires your permission in order to work properly", Toast.LENGTH_SHORT).show();
                finish();

            }
            break;

        }
    }


    private void updateGPS(){
        //get permissions form the user in order to track gps
         //this will then get the current location from the fused client
         //Update the UI
         fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(MainActivity.this);
         if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED){
             //Here when the user provides permission
             fusedLocationProviderClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
                 @Override
                 public void onSuccess(Location location) {
                     // so now that we got permission , put the values of location, into the Ui
                     updateUIValues(location);

                 }
             });
         }
         else{
             if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.N){
                 requestPermissions(new String[] {Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSION_FINE_LOCATION);
             }
         }
     }

    private void updateUIValues( Location location) {

        // now here we will be updating all of the text view object with a new location
        tv_lat.setText(String.valueOf(location.getLatitude()));
        tv_lon.setText(String.valueOf(location.getLatitude()));
        tv_accuracy.setText(String.valueOf(location.getLatitude()));

        //checking to see if it has an altitude
        if (location.hasAltitude()){
            //if it is true get we will get the altitude
            tv_altitude.setText(String.valueOf(location.getAltitude()));
        }
        else {
            //if there is no altitude
            tv_altitude.setText("Altitude not avaliable");
        }

        //checking to see if it has speed
        if (location.hasSpeed()){
            //if it is true get we will get the altitude
            tv_speed.setText(String.valueOf(location.getSpeed()));
        }
        else {
            //if there is no speed
            tv_speed.setText("Sped not avaliable");
        }
    }
}